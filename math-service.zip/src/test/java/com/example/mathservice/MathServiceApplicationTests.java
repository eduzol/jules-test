package com.example.mathservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MathServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
